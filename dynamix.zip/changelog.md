### v1.0 - 15.8.2025
* Initial release